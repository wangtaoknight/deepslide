function res = vec(A)
	res = A(:);
end